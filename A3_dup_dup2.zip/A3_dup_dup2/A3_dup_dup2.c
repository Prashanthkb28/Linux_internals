/* Documentation ------------------------------------------------
Name: PRASHANTH KB
Date: 30/03/2024
Description : WAP to understand usage of dup and dup2 system calls
sample Input:     ./a.out <filename >
Sample Output:
Menu:
1. Dup
2. Dup2
Please enter the Choice: 1
Print this message in the STDOUT.
------------------------------------------------------------------*/

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>

int main (int argc, char* argv [])
{
    /* validating for required number of command line arguments */
	if (argc < 2)	
	{
		printf ("Insufficient arguments\n");
        printf("USAGE :  ./a.out <filename>\n");
		return -1;
	}
    else
	{
		int choice, fd_backup, stdout_backup;

		int fd = open (argv [1], O_WRONLY);						//To Open the File.
		if (fd == -1)									
		{
			perror("Open");
			return -1;
		}
		else													//If the File exists, proceed for the Duplicate System Call.
		{
			fd = open (argv [1], O_WRONLY);			
			
			printf ("Menu:\n1. Dup\n2. Dup2\n");				//Display the menu.
			printf ("Please enter the Choice: ");
			scanf ("%d", &choice);

			if (choice == 1)									// use the dup() function.
			{
				stdout_backup = dup (1);						//Duplicate the 'stdout' File Descriptor in a Backup File Descriptor.
				close (1);										//Close the 'stdout' File Descriptor.
				fd_backup = dup (fd);							//Duplicate the File Descriptor for the File from CLA in a Backup File Descriptor.
				printf ("Print this message in the FILE.\n");	
				fflush (stdout);								//Clear the Output Buffer.

				close (fd_backup);								//Close the 'fd_backup' to free the File Descriptor Index '1'.
				dup (stdout_backup);i							//Duplicate the 'stdout_backup' File Descriptor back to the File Descriptor Index '1'.
				printf ("Print this message in the STDOUT.\n");	
			}
			else if (choice == 2)								//If the User enters '1'; use the dup2() function for the operation.
			{
				stdout_backup = dup2 (1, 5);					//Duplicate the 'stdout' File Descriptor in the File Descriptor Index '5'.
				fd_backup = dup2 (fd, 1);						//Duplicate the File Descriptor for the File from CLA in the File Descriptor Index '1'.
				printf ("Print this message in the FILE.\n");
				fflush (stdout);								//Clear the Output Buffer.

				dup2 (stdout_backup, 1);						//Duplicate the 'stdout_backup' File Descriptor in the File Descriptor Index '1'.
				printf ("Print this message in the STDOUT.\n");	
				close (fd_backup);								//Close the 'fd_backup'.
			}

			close (fd);											//Close the File passed in CLA.
		}
	}

	return 0;
}
