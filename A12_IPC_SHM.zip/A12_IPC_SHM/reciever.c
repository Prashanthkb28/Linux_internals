/* Documentation
Name: PRASHANTH KB
Date: 01/04/2024
Description : 
sample Input and Output
./Process 2

Reading from shared memory :olleh

Writing to Shared memory ...*/

#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <fcntl.h>
#include <sys/ipc.h>

int main ()
{
	sleep (10);												//To wait for the Process-1 to write the Uppercase String in the SHM.

	int shm_id = shmget ('P', 100, 0);						//To Get the SHM ID for the Shared Memory created in Process-1.
	if (shm_id == -1)										//Error Handling.
	{
		perror ("shmget");
		return 0;
	}

	char* ptr = (char*) shmat (shm_id, NULL, 0);			//To Attach the Process-2 with the Shared Memory.
	if (ptr == (char*) (-1))								//Error Handling.
	{
		perror ("shmat");
		return 0;
	}

	printf ("Reading from the Shared Memory: %s\n", ptr);

	int len = 0;
	while (ptr [++len] != '\0');							//To find the Length of the String read from the SHM.

	printf ("Writing to the Shared Memory...\n");

	for (int i = 0; i <= (len / 2); i++)					//To Reverse the String read from the SHM.
	{
		char temp = ptr [i];
		ptr [i] = ptr [len - i - 1];
		ptr [len - i - 1] = temp;
	}

	shmdt (ptr);											//To Detach the Process-2 from the Shared Memory.

	return 0;
}
