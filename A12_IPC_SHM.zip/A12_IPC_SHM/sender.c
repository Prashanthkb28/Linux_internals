/* Documentation
Name: PRASHANTH KB
Date: 1/04/2024
Description : Implement communication between two different processes using SHM
sample Input and output:
Run the two process executable in two different tabs 

1. ./Process1 

Enter the string: Hello

Writing to shared memory ......

Reading from shared memory:  OLLEH

*/

#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <fcntl.h>
#include <sys/ipc.h>

int main ()
{
	int shm_id = shmget ('P', 100, IPC_CREAT | 0664);		//To Create a Shared Memory segment with the given File permission.
	if (shm_id == -1)										//Error Handling.
	{
		perror ("shmget");
		return 0;
	}

	char* ptr = (char*) shmat (shm_id, NULL, 0);			//To Attach the Process-1 with the Shared Memory.
	if (ptr == (char*) (-1))								//Error Handling.
	{
		perror ("shmat");
		return 0;
	}

	printf ("Enter the String to be written: ");
	scanf ("%[^\n]", ptr);
	printf ("Writing to the Shared Memory...\n");

	int i = 0;
	while (ptr [i] != '\0')									//To Convert the read String into Uppercase.
	{
		if ((ptr [i] >= 'a') && (ptr [i] <= 'z'))
		{
			ptr [i] -= 32;
		}
		
		i += 1;
	}

	sleep (10);												//To Wait for the Process-2 to read and reverse the written String on the SHM.

	printf ("Reading from the Shared Memory: %s\n", ptr);

	shmdt (ptr);											//To Detach the Process-1 from the Shared Memory.

	shmctl (shm_id, IPC_RMID, NULL);						//To Remove the Shared Memory segment.

	return 0;
}
