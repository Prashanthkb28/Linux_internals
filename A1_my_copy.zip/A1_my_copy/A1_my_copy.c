/* Documentation------------------------------------------------------------------
NAME : PRASHANTH KB
DATE : 28/03/2024
DESCRIPTION : Implemnting the cp command with -p option

Input  : ./a.out -p source.txt dest.txt
output :  File copied successfully

---------------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>

#define BUFF_SIZE 4096

int  my_copy(int source_fd, int dest_fd)
{
    char buffer[BUFF_SIZE];
    ssize_t bytes_read, bytes_written;

    while ((bytes_read = read(source_fd, buffer, BUFF_SIZE)) > 0) {
        bytes_written = write(dest_fd, buffer, bytes_read);
        if (bytes_written != bytes_read) {
            perror("Write error");
            return -1;
        }
    }

    if (bytes_read < 0) {
        perror("Read error");
        return -1;
    }
}

int main(int argc, char *argv[]) 
{
    if (argc < 3)
    {
        printf("Insufficient arguments\n");
        printf("Usage: ./my_copy [option] source_file destination_file\n");
        return -1;
    }

    int copy_permissions = 0;
    int arg_index = 1;
    if (strcmp(argv[arg_index], "-p") == 0)
    {
        copy_permissions = 1;
        arg_index++;
    }

    if (argc - arg_index < 2)
    {
        printf("Insufficient arguments\n");
        printf("Usage: ./my_copy [option] source_file destination_file\n");
        return -1;
    }

    char *source_file = argv[arg_index];
    char *dest_file = argv[arg_index + 1];

    int source_fd = open(source_file, O_RDONLY);
    if (source_fd == -1) 
    {
        perror("Source file open error");
        return -1;
    }

    int dest_fd=open(dest_file,O_WRONLY);
    if(dest_fd == -1)
    {
        dest_fd = open(dest_file,O_WRONLY|O_CREAT,0664);
        if(dest_fd == -1)
        {
            perror("Destination file open error");
            return -1;
        }
        my_copy(source_fd , dest_fd);
    }
    else
    {
        char ch;
        printf("Do you want to overwrite (y/n): ");
        scanf("%c",&ch);
        if(ch == 'Y' || ch == 'y')
        {
            my_copy(source_fd, dest_fd);
        }
    }
    if (copy_permissions) 
    {
        struct stat file_info;
        if (fstat(source_fd, &file_info) == -1) {
            perror("fstat error");
            return -1;
        }
        if (fchmod(dest_fd, file_info.st_mode) == -1) {
            perror("fchmod error");
            return -1;
        }
    }
    close(source_fd);
    close(dest_fd);
    printf("File copied successfully\n");
    return 0;
}

